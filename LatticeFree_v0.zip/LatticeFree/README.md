# LatticeFree

**TPMS lattice infill generator for FreeCAD** — fill any solid with a
gyroid lattice using implicit modelling: outer shell, smooth fillet at
the shell/lattice junction, relative-density control, density grading
(dense skin, light core), and FEM mid-surface export. No CAD booleans,
no mandatory external dependencies.

Built on the implicit-field pipeline: signed distance field of the
part + gyroid field, combined with `min`/`max`/smooth-max operations,
extracted with marching tetrahedra into a single watertight mesh.

---

## Requirements

- **FreeCAD 1.0+** (uses the bundled Python, PySide, and `Mesh`/`Part`
  modules).
- **numpy** — bundled with FreeCAD.
- **scipy** — *optional*. If present, the signed distance field is
  computed exactly (Euclidean); otherwise a built-in fallback is used.
- No other dependencies. The FEM export uses internal `.inp`/`.msh`
  writers — no `gmsh` module required.

## Installation (manual)

LatticeFree is a standard FreeCAD external workbench. Install it by
copying the `LatticeFree` folder into your FreeCAD `Mod` directory.

**Mod directory location:**

- **macOS:** `~/Library/Application Support/FreeCAD/Mod/`
- **Windows:** `%APPDATA%\FreeCAD\Mod\`
- **Linux:** `~/.local/share/FreeCAD/Mod/`

**Steps:**

1. Unzip this archive. You get a folder named `LatticeFree`.
2. Copy the whole `LatticeFree` folder into the `Mod` directory above.
   The final path must look like:
   `.../FreeCAD/Mod/LatticeFree/InitGui.py`
3. Fully quit and restart FreeCAD.
4. In the workbench selector (top toolbar dropdown), choose
   **LatticeFree**.
5. A toolbar/menu button **"Genera infill TPMS"** appears. Click it.

> Tip: if the workbench does not show up, open the Python console
> (View > Panels > Python console) and check the report view for a
> line `LatticeFree workbench caricato.` at startup. If there is an
> import error, it will be printed there.

## Usage

1. (Optional) Select a solid in the document — the lattice will be
   confined to its volume. With no selection, a demo cube is produced.
2. Launch **Genera infill TPMS**.
3. Set the parameters in the dialog:
   - **Componente** — target solid (or demo cube).
   - **Output** — *mesh* (fast, for printing) or *solid CAD* (slow).
   - **Spessore shell** — outer skin thickness (0 = lattice exposed).
   - **Dimensione cella** — gyroid unit cell size (mm).
   - **Densita' relativa (esterna)** — wall density, guided 10–70%.
   - **Grading** — optional: dense skin, light core, with a printable
     minimum-thickness clamp (nozzle diameter).
   - **Raggio raccordo** — fillet radius at shell/lattice junction.
   - **Dimensione elemento griglia** — sampling resolution (auto =
     cell/15 recommended).
   - **Smoothing / Decimazione** — mesh post-processing.
   - **Esporta superficie media per FEM** — optional mid-surface
     export to `.inp` (CalculiX/Abaqus) or `.msh` (Gmsh).
4. Click **Genera**. Progress is printed in the report view.

### Performance notes

- Grid size grows with the cube of resolution. On modest laptops, stay
  in **mesh** mode with **auto** element size; very fine grids and
  heavy smoothing can exhaust RAM.
- The dialog shows a live estimate of grid points and blocks
  configurations above ~40 million points.
- "Solid CAD" mode is slow (mesh→BRep conversion); use only when a
  true CAD solid is needed downstream.

## What works and what doesn't (honest scope)

**Works (validated):** gyroid infill, parametric shell following holes
and cavities, exact-band SDF (no terracing on curved surfaces), smooth
fillet, relative-density control with a measured calibration table,
density grading with printability clamp, watertight mesh cleanup,
FEM mid-surface export.

**Out of scope (research-grade problems):**
- *Automatic FEM-grade remeshing of TPMS* (near-equilateral triangles
  produced by the tool itself). The mid-surface export is clean but
  **not** FEM-grade; run a remesh in your solver (PrePoMax, Gmsh
  standalone) for analysis-quality elements.
- *Grading from an external optimization density map* (e.g. topology
  optimization output).
- *Other TPMS* (Schwarz P, Diamond, double gyroid) — gyroid only for
  now.

## Project structure

```
LatticeFree/
  InitGui.py            # workbench registration (loaded by FreeCAD)
  package.xml.bak       # Addon Manager metadata (disattivato: vedi nota avvio)
  README.md
  LICENSE
  Resources/icons/
    freelattice.svg     # workbench icon
  freelattice/
    __init__.py
    engine.py           # calculation core (no Qt, no FreeCAD GUI deps)
    commands.py         # GUI dialog + command (uses engine)
```

The calculation core (`engine.py`) is deliberately decoupled from the
interface, so it can be reused in a standalone app or CLI.

## Startup loading note (important)

This workbench installs the classic way: `Mod/LatticeFree/InitGui.py`.
On FreeCAD 1.1 an active `package.xml` makes the loader treat the addon as a
"package-format" module and look for a namespaced `freecad/<name>/init_gui.py`
layout — which this addon does not use — so the classic `InitGui.py` scan gets
bypassed and the workbench silently fails to appear at startup. For that reason
the metadata file ships here as `package.xml.bak` (inactive). Do not rename it
back to `package.xml` unless you also convert the addon to the namespaced layout.

On FreeCAD 1.x the user `Mod` directory is versioned, e.g. on macOS:
`~/Library/Application Support/FreeCAD/v1-1/Mod/`.

## License

LGPL-2.1-or-later (same family as FreeCAD).
