# -*- coding: utf-8 -*-
"""LatticeFree — TPMS lattice infill generator for FreeCAD."""
__version__ = "1.0.0"
